import os
import json
import logging
import sys
import joblib
import numpy as np

# Configure container logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def _average_path_length(n_samples):
    """Calculates standard average path length c(n) of BST."""
    n = np.asarray(n_samples, dtype=np.float64)
    avg = np.zeros_like(n)
    m1 = n <= 1
    m2 = n == 2
    m3 = n > 2
    avg[m1] = 0.0
    avg[m2] = 1.0
    avg[m3] = 2.0 * (np.log(n[m3] - 1.0) + 0.5772156649) - (2.0 * (n[m3] - 1.0) / n[m3])
    return avg

class JSONIsolationForest:
    """Pure NumPy IsolationForest + StandardScaler evaluator (version-agnostic)."""
    def __init__(self, model_dict):
        scaler_info = model_dict.get("scaler", {})
        self.mean = np.array(scaler_info["mean"]) if scaler_info.get("mean") else None
        self.scale = np.array(scaler_info["scale"]) if scaler_info.get("scale") else None
        
        iforest_info = model_dict.get("iforest", {})
        self.max_samples = iforest_info.get("max_samples", 100)
        self.offset = iforest_info.get("offset", -0.5)
        self.trees = iforest_info.get("trees", [])
        self.c_max_samples = _average_path_length([self.max_samples])[0]

    def _transform(self, X):
        if self.mean is not None and self.scale is not None:
            return (X - self.mean) / self.scale
        return X

    def decision_function(self, X):
        X_scaled = self._transform(X)
        n_samples = X_scaled.shape[0]
        paths = np.zeros((n_samples, len(self.trees)))

        for i, sample in enumerate(X_scaled):
            for t_idx, tree in enumerate(self.trees):
                node = 0
                depth = 0
                left = tree["left"]
                right = tree["right"]
                feat = tree["feature"]
                thresh = tree["threshold"]
                n_node_samples = tree["n_node_samples"]

                while left[node] != -1 and right[node] != -1:
                    f = feat[node]
                    if sample[f] <= thresh[node]:
                        node = left[node]
                    else:
                        node = right[node]
                    depth += 1

                leaf_samples = n_node_samples[node]
                h = depth + _average_path_length([leaf_samples])[0]
                paths[i, t_idx] = h

        mean_h = np.mean(paths, axis=1)
        score_samples = - (2.0 ** (- mean_h / self.c_max_samples))
        return score_samples - self.offset

    def predict(self, X):
        scores = self.decision_function(X)
        return np.where(scores >= 0, 1, -1)

def model_fn(model_dir):
    """
    Loads model artifact.
    Prioritizes model.json for 100% version-agnostic inference across Scikit-Learn versions.
    Falls back to joblib.load(model.joblib) if JSON is unavailable.
    """
    logger.info(f"[*] Container initializing model load from: {model_dir}")
    
    # 1. Prioritize model.json (Version-Agnostic)
    json_path = os.path.join(model_dir, "model.json")
    if not os.path.exists(json_path):
        json_path = os.path.join(model_dir, "code", "model.json")

    if os.path.exists(json_path):
        try:
            logger.info(f"[*] Loading JSON model representation: {json_path}")
            with open(json_path, "r", encoding="utf-8") as f:
                model_dict = json.load(f)
            
            if "iforest" in model_dict and "trees" in model_dict["iforest"] and len(model_dict["iforest"]["trees"]) > 0:
                model = JSONIsolationForest(model_dict)
                logger.info(f"[OK] Successfully loaded JSON IsolationForest model (Trees: {len(model.trees)})")
                return model
        except Exception as e:
            logger.warning(f"[!] JSON model load failed: {str(e)}. Falling back to joblib...")

    # 2. Fallback to model.joblib
    joblib_path = os.path.join(model_dir, "model.joblib")
    if not os.path.exists(joblib_path):
        joblib_path = os.path.join(model_dir, "code", "model.joblib")

    if os.path.exists(joblib_path):
        try:
            model = joblib.load(joblib_path)
            logger.info(f"[OK] joblib artifact loaded successfully. Type: {type(model)}")
            return model
        except Exception as e:
            logger.error(f"[!] Exception during joblib.load: {str(e)}", exc_info=True)
            raise e

    raise FileNotFoundError(f"No valid model artifact (model.json or model.joblib) found inside {model_dir}")

def input_fn(request_body, request_content_type):
    """Parses incoming eBPF telemetry JSON payload."""
    logger.info(f"[*] Request content-type: {request_content_type}")
    if request_content_type == "application/json":
        data = json.loads(request_body)
        if isinstance(data, dict) and "features" in data:
            data = data["features"]
        
        arr = np.array(data, dtype=np.float64)
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)
        return arr
    raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model):
    """Executes inference through JSONIsolationForest or Pipeline."""
    try:
        raw_pred = model.predict(input_data)[0]
        score = float(model.decision_function(input_data)[0])

        return {
            "is_anomaly": 1 if raw_pred == -1 else 0,
            "raw_predict": int(raw_pred),
            "anomaly_score": round(score, 4)
        }
    except Exception as e:
        logger.error(f"[!] Error during prediction execution: {str(e)}", exc_info=True)
        raise e

def output_fn(prediction, accept):
    """Formats response output into JSON."""
    if accept in ["application/json", "*/*"]:
        return json.dumps(prediction), "application/json"
    raise ValueError(f"Unsupported accept type: {accept}")
